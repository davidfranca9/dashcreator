# Avaliação UX da página High Performance Creator

Avaliação feita como UI/UX designer sobre o projeto `high-performance-creator-ajustado.zip`.
A identidade foi mantida (paleta, Montserrat, cantos retos, sombra dura) e **todo o texto é o
original**. O trabalho foi em hierarquia, leitura, contraste, celular e conversão.
Comparativo visual em [avaliacao/antes-e-depois.png](avaliacao/antes-e-depois.png).

## Como rodar

```sh
cd high-performance-creator
npm install     # só na primeira vez
npm run dev     # abre em http://localhost:8080
npm run build   # versão de produção
```

## O que estava errado

| Área | Problema | Medida |
| --- | --- | --- |
| Contraste | Rótulos azuis sobre azul-marinho ("Tudo que está incluso") quase ilegíveis | 3,2:1 (mínimo 4,5:1) |
| Contraste | Texto branco a 85% sobre o azul da seção da Layfe; rótulo a 70% | 3,7:1 e 2,9:1 |
| Contraste | Rótulos pequenos em azul sobre o creme | 4,2:1 |
| Leitura | Tudo centralizado, inclusive parágrafos de 5 linhas (história da Layfe, FAQ) | |
| Cards do programa | 7 cards em 3 colunas deixam o 7º sozinho; conteúdo centralizado na vertical desalinha os números | |
| Celular | Programa ocupava 2211px de rolagem (27% da página) | |
| Confiança | A página vende a autoridade da Layfe e não mostra o rosto dela | |
| Prova | Os números do faturamento (R$ 1 mil até R$ 10 mil) estavam escondidos no meio de um parágrafo | |
| Fluxo | A oferta vinha antes de "Quem vai te guiar" | |
| Conversão | 3 botões iguais e nenhum botão fixo numa página longa de celular | |
| FAQ | Seta colada no texto, itens sem cara de clicável | |
| Acessibilidade | Botão com foco invisível (anel de 1px azul sobre botão azul), sem "pular para o conteúdo", `lang="en"` numa página em português (o Chrome oferece traduzir) | |
| Detalhes | `twitter:site` = @Lovable, telas de erro e 404 em inglês, botão da oferta apontando para ela mesma | |

## O que mudou

- **Hero**: cabeçalho com marca, foto pequena da Layfe e três fatos (04 encontros ao vivo, segundas
  às 19h, 45 dias de acesso, todos tirados do próprio texto). O botão principal cabe na primeira
  tela do celular e de notebook de 768px.
- **Contraste**: azul de tinta um passo mais escuro (`--primary-ink`) para texto pequeno sobre
  fundo claro; amarelo da marca nos rótulos sobre azul-marinho (9,8:1); texto branco pleno sobre o
  azul. Auditoria automática (axe-core, WCAG 2.1 AA): 0 violações no desktop e no celular.
- **Programa**: grade 4 + 3 no desktop, 2 colunas no tablet e lista compacta no celular
  (2211px caiu para 1531px). Texto alinhado à esquerda.
- **Quem vai te guiar**: foto real da Layfe (a mesma do site dela, otimizada de 1,3 MB para 110 KB),
  texto legível e um gráfico simples com os números que ela mesma cita.
- **Ordem**: "Quem vai te guiar" agora vem antes de "Tudo que está incluso" e da oferta, para a pessoa
  conhecer quem guia antes de ver o preço. Para desfazer, basta mover `<About />` em
  `src/routes/index.tsx`.
- **Oferta**: preço com hierarquia (R$ menor, 597 grande), fatos resumidos e botão único.
- **Botões**: efeito de apertar (a sombra dura afunda no hover e no clique), anel de foco visível,
  botão no cabeçalho (desktop) e barra fixa com preço (celular), que some quando a oferta está na tela.
- **FAQ**: cartões com ícone de mais/menos, item aberto destacado, um aberto por vez, alvo de toque de 80px.
- **Movimento**: entrada suave do topo e ao rolar, tudo desligado com `prefers-reduced-motion` e
  sempre visível sem JavaScript.
- **Base**: `lang="pt-BR"`, link "Ir para o conteúdo", marcos (`header`, `main`, `footer`), telas de
  erro em português, `twitter:site` removido, dois travessões do FAQ trocados por vírgula.

## O que falta com você

Tudo isso fica em `src/config.ts`, com instruções nos comentários:

1. **Link do checkout** (`CHECKOUT_URL`). Hoje o botão da oferta ainda aponta para `#inscricao`.
2. **Vídeo do depoimento** (`TESTIMONIAL_VIDEO`). Aceita arquivo em `public/` ou link de
   incorporação do YouTube/Vimeo, em pé ou deitado.
3. **Print da área de membros** (`PLATFORM_SCREENSHOT`).
4. **Rodapé**: termos, privacidade, contato/WhatsApp e CNPJ ainda não existem na página.
5. **Imagem de compartilhamento** (`og:image`): sem ela o link no WhatsApp aparece sem prévia.

## Para conferir

- O gráfico rotula as colunas como "Antes, Mês 1, Mês 2, Mês 3". Isso vem de "em 3 meses, saí de
  R$ 1 mil para R$ 5 mil, R$ 8 mil e R$ 10 mil, respectivamente". Se não for essa a leitura, é só
  ajustar `points` em `src/components/hpc/growth-chart.tsx` (ou remover o gráfico).
- A etiqueta da foto diz "Mentora da HPC".
- 12x de R$ 60,66 soma R$ 727,92, ou seja, o parcelado tem acréscimo sobre os R$ 597 à vista.
  Vale deixar isso claro no texto do preço.
