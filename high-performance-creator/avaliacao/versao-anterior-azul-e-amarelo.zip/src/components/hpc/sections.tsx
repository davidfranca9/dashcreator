import type { CSSProperties } from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import {
  CalendarDays,
  Check,
  Clock,
  LayoutDashboard,
  Minus,
  Play,
  Plus,
  Target,
  Video,
  Zap,
} from "lucide-react";

import { Accordion, AccordionContent, AccordionItem } from "@/components/ui/accordion";
import { PLATFORM_SCREENSHOT, TESTIMONIAL_VIDEO, CHECKOUT_URL } from "@/config";
import { faq, included, modules } from "@/lib/content";
import { heroDelay, revealDelay } from "@/lib/landing";
import { cn } from "@/lib/utils";

import { GrowthChart } from "./growth-chart";
import { Eyebrow, SalesButton, SectionTitle } from "./primitives";

const facts = [
  { Icon: Video, label: "04 encontros ao vivo" },
  { Icon: CalendarDays, label: "Segundas, às 19h" },
  { Icon: Clock, label: "45 dias de acesso" },
];

const FRAME_YELLOW = { "--frame-color": "var(--color-signal)" } as CSSProperties;

/* -------------------------------------------------------------------------- */
/*  Cabeçalho e barra fixa                                                    */
/* -------------------------------------------------------------------------- */

export function Header({ showCta }: { showCta: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 sm:px-8">
        <a
          href="#top"
          aria-label="High Performance Creator, voltar ao topo"
          className="flex items-center gap-3"
        >
          <span className="display-type grid size-10 place-items-center bg-primary text-[0.95rem] text-primary-foreground">
            HPC
          </span>
          <span className="text-[0.65rem] font-semibold uppercase leading-[1.4] tracking-[0.16em]">
            High Performance
            <br />
            Creator
          </span>
        </a>

        <div
          inert={!showCta}
          className={cn(
            "hidden pb-2 transition-opacity duration-200 md:block",
            showCta ? "opacity-100" : "pointer-events-none opacity-0",
          )}
        >
          <SalesButton size="header">Quero mudar meu jogo</SalesButton>
        </div>
      </div>
    </header>
  );
}

// No celular, o botão principal acompanha a rolagem: a página é longa e o toque precisa estar à mão.
export function StickyBar({ visible }: { visible: boolean }) {
  return (
    <div
      inert={!visible}
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      className={cn(
        "fixed inset-x-0 bottom-0 z-50 border-t-2 border-foreground bg-background/95 backdrop-blur-md transition-transform duration-300 md:hidden",
        visible ? "translate-y-0" : "translate-y-full",
      )}
    >
      <div className="flex items-center gap-4 px-4 pb-4 pt-3">
        <p className="shrink-0 leading-none">
          <span className="display-type block text-2xl text-primary-ink">R$ 597</span>
          <span className="mt-1 block text-[0.7rem] font-medium text-ink-soft">
            12x de R$ 60,66
          </span>
        </p>
        <SalesButton size="bar" className="flex-1">
          Quero mudar meu jogo
        </SalesButton>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Topo                                                                      */
/* -------------------------------------------------------------------------- */

export function Hero() {
  return (
    <section id="top" className="relative isolate">
      <div
        aria-hidden
        className="bg-dots pointer-events-none absolute inset-0 -z-10 [mask-image:radial-gradient(ellipse_at_50%_40%,black_20%,transparent_70%)]"
      />
      <div className="mx-auto max-w-5xl px-5 pb-12 pt-5 sm:px-8 sm:pb-20 sm:pt-6">
        <div className="relative px-2 py-8 text-center sm:px-14 sm:py-9">
          <span aria-hidden className="corner-frame pointer-events-none absolute inset-0" />

          <div className="flex flex-col items-center">
            <p
              style={heroDelay(0)}
              className="hero-in inline-flex items-center gap-2 border border-primary-ink/50 bg-card px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-primary-ink"
            >
              <Zap className="size-4" aria-hidden /> Edição especial Black Friday
            </p>

            <h1
              style={heroDelay(80)}
              className="hero-in display-type mt-6 max-w-4xl text-balance text-[clamp(2.35rem,6vw,4.4rem)] leading-[1.03]"
            >
              Transforme seu Instagram em um{" "}
              <span className="box-decoration-clone text-primary [box-shadow:inset_0_-0.14em_0_var(--color-signal)]">
                ímã de marcas.
              </span>
            </h1>

            <p
              style={heroDelay(200)}
              className="hero-in mt-6 max-w-3xl text-pretty text-base leading-relaxed text-ink-soft sm:text-lg"
            >
              UGC não precisa postar os trabalhos que faz para as marcas, mas uma UGC que performa é
              constante nas redes sociais e cria conteúdo estratégico para ser notada pelas marcas,
              receber inbounds e ter previsibilidade.
            </p>
            <p
              style={heroDelay(280)}
              className="hero-in mt-3 max-w-3xl text-pretty text-base font-semibold leading-relaxed text-foreground sm:text-lg"
            >
              É uma estrutura que vai funcionar por você. Vai vender você antes mesmo de a marca
              entrar em contato.
            </p>

            <div style={heroDelay(360)} className="hero-in mt-7 w-full sm:w-auto">
              <SalesButton id="cta-hero" className="w-full sm:w-auto" />
            </div>

            <div
              style={heroDelay(460)}
              className="hero-in mt-9 flex flex-wrap items-center justify-center gap-x-8 gap-y-4"
            >
              <div className="flex items-center gap-3 text-left">
                <img
                  src="/layfe-avatar.jpg"
                  alt=""
                  width={44}
                  height={44}
                  className="size-11 border-2 border-foreground object-cover"
                />
                <p className="text-sm leading-tight">
                  <span className="block font-semibold">Mentoria com a Layfe</span>
                  <span className="block text-ink-soft">Em grupo e ao vivo</span>
                </p>
              </div>
              <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm font-medium text-ink-soft">
                {facts.map(({ Icon, label }) => (
                  <li key={label} className="flex items-center gap-2">
                    <Icon className="size-4 text-primary-ink" aria-hidden />
                    {label}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Prova: depoimento em vídeo                                                */
/* -------------------------------------------------------------------------- */

function isEmbed(src: string) {
  return /youtube\.com\/embed|youtube-nocookie\.com\/embed|player\.vimeo\.com/.test(src);
}

function TestimonialVideo() {
  const video = TESTIMONIAL_VIDEO;

  return (
    <div
      style={FRAME_YELLOW}
      className={cn("relative mx-auto", video?.vertical ? "max-w-xs" : "max-w-3xl")}
    >
      <span aria-hidden className="corner-frame pointer-events-none absolute -inset-3" />
      <div
        className={cn(
          "relative overflow-hidden bg-[oklch(0.2_0.08_258)] ring-1 ring-primary-foreground/15",
          video?.vertical ? "aspect-[9/16]" : "aspect-video",
        )}
      >
        {video ? (
          isEmbed(video.src) ? (
            <iframe
              src={video.src}
              title="Depoimento de uma aluna da mentoria"
              loading="lazy"
              allow="accelerometer; autoplay; encrypted-media; picture-in-picture"
              allowFullScreen
              className="absolute inset-0 size-full"
            />
          ) : (
            <video
              controls
              playsInline
              preload="metadata"
              poster={video.poster}
              className="absolute inset-0 size-full object-cover"
            >
              <source src={video.src} />
            </video>
          )
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-5 p-6">
            <span className="grid size-16 place-items-center bg-signal text-foreground shadow-[6px_6px_0_var(--color-primary)] sm:size-20">
              <Play className="size-7 fill-current sm:size-9" aria-hidden />
            </span>
            <p className="text-sm font-medium text-primary-foreground/75">
              Espaço reservado para o vídeo de depoimento
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export function Proof() {
  return (
    <section
      aria-labelledby="prova-title"
      className="on-dark bg-secondary py-16 text-secondary-foreground sm:py-24"
    >
      <div className="mx-auto max-w-5xl px-5 text-center sm:px-8">
        <div data-reveal>
          <Eyebrow tone="dark">Seu perfil pode trabalhar por você!</Eyebrow>
        </div>
        <SectionTitle id="prova-title" className="mx-auto mt-5 max-w-3xl">
          <span data-reveal className="block" style={revealDelay(80)}>
            Ela entrou na mentoria e, <span className="text-signal">em 2 semanas</span>, mesmo sem
            ter portfólio, <span className="text-signal">fechou um contrato anual.</span>
          </span>
        </SectionTitle>
        <div data-reveal className="mt-14" style={revealDelay(120)}>
          <TestimonialVideo />
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Conteúdo                                                                  */
/* -------------------------------------------------------------------------- */

export function Learn() {
  return (
    <section
      id="programa"
      aria-labelledby="programa-title"
      className="bg-surface-blue py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div data-reveal className="text-center">
          <SectionTitle id="programa-title">O que você vai aprender</SectionTitle>
        </div>

        {/* 7 módulos: 4 + 3 no desktop, 2 colunas no tablet, lista compacta no celular. */}
        <ol className="mt-10 grid gap-3 sm:mt-14 sm:grid-cols-2 sm:gap-4 lg:grid-cols-12">
          {modules.map((module, index) => (
            <li
              key={module.number}
              data-reveal
              style={revealDelay((index % 4) * 70)}
              className={cn(
                index < 4 ? "lg:col-span-3" : "lg:col-span-4",
                index === modules.length - 1 && "sm:col-span-2",
              )}
            >
              <div className="grid h-full grid-cols-[2.5rem_1fr] items-center gap-x-4 gap-y-3 border border-foreground/15 bg-card p-5 sm:p-6 lg:grid-cols-1 lg:items-start lg:gap-y-4">
                <span className="grid size-10 place-items-center bg-signal text-sm font-semibold text-foreground">
                  {module.number}
                </span>
                <h3 className="display-type text-lg leading-snug sm:text-xl">{module.title}</h3>
                <p className="col-span-2 text-[0.9375rem] leading-relaxed text-ink-soft lg:col-span-1">
                  {module.description}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function Platform() {
  return (
    <section aria-labelledby="plataforma-title" className="py-16 sm:py-24">
      <div className="mx-auto max-w-5xl px-5 text-center sm:px-8">
        <div data-reveal>
          <Eyebrow>Por dentro da mentoria</Eyebrow>
          <SectionTitle id="plataforma-title" className="mt-4">
            Área de membros HPC
          </SectionTitle>
        </div>

        <div
          data-reveal
          style={revealDelay(100)}
          className="mt-10 border-2 border-foreground bg-card text-left shadow-[10px_10px_0_var(--color-primary)] sm:mt-14 sm:shadow-[14px_14px_0_var(--color-primary)]"
        >
          <div
            aria-hidden
            className="flex items-center gap-1.5 border-b-2 border-foreground bg-muted px-3 py-2.5"
          >
            <span className="size-2.5 bg-foreground/30" />
            <span className="size-2.5 bg-foreground/30" />
            <span className="size-2.5 bg-foreground/30" />
          </div>
          {PLATFORM_SCREENSHOT ? (
            <img
              src={PLATFORM_SCREENSHOT}
              alt="Tela da área de membros da High Performance Creator"
              loading="lazy"
              decoding="async"
              className="block w-full"
            />
          ) : (
            <div className="flex aspect-[16/10] flex-col items-center justify-center gap-4 p-6 text-center">
              <LayoutDashboard className="size-12 text-primary-ink" strokeWidth={1.5} aria-hidden />
              <p className="text-sm font-medium text-ink-soft">
                Espaço reservado para o print da plataforma
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Quem vai te guiar                                                         */
/* -------------------------------------------------------------------------- */

export function About() {
  return (
    <section
      id="layfe"
      aria-labelledby="layfe-title"
      className="on-dark bg-primary py-16 text-primary-foreground sm:py-24"
    >
      <div className="mx-auto grid max-w-6xl gap-14 px-5 sm:px-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-16">
        <div
          data-reveal
          className="mx-auto w-full max-w-sm pb-5 lg:sticky lg:top-28 lg:max-w-none lg:self-start"
        >
          <div className="relative">
            <img
              src="/layfe.jpg"
              alt="Layfe sorrindo, de blusa listrada em azul e branco"
              width={900}
              height={1114}
              loading="lazy"
              decoding="async"
              className="aspect-square w-full border-2 border-foreground object-cover object-[50%_18%] shadow-[10px_10px_0_var(--color-signal)] sm:shadow-[14px_14px_0_var(--color-signal)] lg:aspect-[4/5]"
            />
            <p className="absolute -bottom-5 left-4 bg-foreground px-4 py-2.5 text-sm font-semibold leading-tight text-primary-foreground">
              Layfe
              <span className="block text-xs font-medium text-primary-foreground/75">
                Mentora da HPC
              </span>
            </p>
          </div>
        </div>

        <div>
          <div data-reveal>
            <Eyebrow tone="dark">Quem vai te guiar?</Eyebrow>
            <SectionTitle id="layfe-title" className="mt-4">
              Prazer, eu sou a Layfe!
            </SectionTitle>
          </div>

          <div className="mt-8 space-y-5 text-pretty text-[1.0625rem] font-medium leading-[1.75] sm:text-lg">
            <p data-reveal>
              Assim como você, eu cheguei a um momento da minha vida em que sentia que estava
              perdendo tempo. Via dar certo para todo mundo, menos para mim. Eu não entendia o que
              estava fazendo de errado e não gostava de abordar marcas.
            </p>
            <p data-reveal>
              Enquanto todo mundo recebia propostas, o meu perfil continuava no limbo do
              esquecimento. Tudo mudou quando passei a gerenciar o meu perfil como uma empresa.
            </p>
            <p data-reveal>
              Em 3 meses, saí de um faturamento de R$&nbsp;1&nbsp;mil para{" "}
              <strong className="font-semibold">
                R$&nbsp;5&nbsp;mil, R$&nbsp;8&nbsp;mil e R$&nbsp;10&nbsp;mil
              </strong>
              , respectivamente. Quando bati a minha meta, saí do CLT.
            </p>

            <div className="py-3">
              <GrowthChart />
            </div>

            <p data-reveal>
              Ter um perfil de impacto foi o que me permitiu sair do CLT. Depois de validar meu
              método e conquistar a liberdade de viver 100% do digital, coloquei toda essa estrutura
              dentro da Mentoria High Performance Creator.
            </p>
            <p
              data-reveal
              className="border-l-4 border-signal pl-5 text-xl font-semibold leading-snug sm:text-2xl"
            >
              A HPC veio para transformar creators nas profissionais mais bem requisitadas pelas
              marcas.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  O que está incluso e oferta                                               */
/* -------------------------------------------------------------------------- */

export function Included() {
  return (
    <section
      id="incluso"
      aria-labelledby="incluso-title"
      className="on-dark bg-secondary py-16 text-secondary-foreground sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div data-reveal className="mx-auto max-w-3xl text-center">
          <Eyebrow tone="dark">Tudo que está incluso</Eyebrow>
          <SectionTitle id="incluso-title" className="mt-4">
            Transforme o seu perfil no Instagram em um canal de aquisição de clientes!
          </SectionTitle>
          <p className="mt-5 text-lg text-primary-foreground/80">
            Tudo que você precisa para fazer o seu perfil vender por você.
          </p>
        </div>

        <ul className="mx-auto mt-10 grid max-w-5xl gap-3 sm:mt-14 sm:grid-cols-2 sm:gap-4">
          {included.map((item, index) => (
            <li
              key={item}
              data-reveal
              style={revealDelay((index % 2) * 70)}
              className="flex items-start gap-4 border border-primary-foreground/20 bg-primary-foreground/5 p-4 sm:p-5"
            >
              <span className="mt-px grid size-6 shrink-0 place-items-center bg-signal text-foreground">
                <Check className="size-4" strokeWidth={3} aria-hidden />
              </span>
              <span className="font-medium leading-snug">{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function Offer() {
  return (
    <section id="inscricao" aria-labelledby="oferta-title" className="py-16 sm:py-24">
      <div className="mx-auto max-w-4xl px-5 sm:px-8">
        <div
          data-reveal
          className="border-2 border-foreground bg-card p-6 text-center shadow-[8px_8px_0_var(--color-primary)] sm:p-12 sm:shadow-[12px_12px_0_var(--color-primary)]"
        >
          <div className="flex flex-col items-center">
            <p className="inline-flex items-center gap-2 bg-signal px-3 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-foreground">
              <CalendarDays className="size-4" aria-hidden /> Última turma antes da Black Friday
            </p>
            <SectionTitle id="oferta-title" className="mt-6 text-[clamp(2.25rem,6vw,3.75rem)]">
              Edição Especial!
            </SectionTitle>
            <p className="mt-5 max-w-2xl text-pretty leading-relaxed text-ink-soft sm:text-lg">
              A última oportunidade de entrar na HPC antes da Black Friday e preparar seu perfil,
              seus conteúdos e sua prospecção para um dos períodos mais importantes do ano para as
              marcas.
            </p>

            <div className="mt-9 w-full border-y border-foreground/15 py-8">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-ink-soft">
                Investimento
              </p>
              <p className="display-type mt-3 text-[clamp(3.5rem,11vw,5.5rem)] leading-none text-primary-ink">
                <span className="align-top text-[0.36em] leading-none">R$</span>
                <span className="ml-1">597</span>
              </p>
              <p className="mt-3 font-medium">à vista ou 12x de R$ 60,66</p>
              <ul className="mt-6 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm font-medium text-ink-soft">
                {facts.map(({ Icon, label }) => (
                  <li key={label} className="flex items-center gap-2">
                    <Icon className="size-4 text-primary-ink" aria-hidden />
                    {label}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <SalesButton href={CHECKOUT_URL} className="mt-9 w-full sm:w-auto sm:min-w-96" />
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------------------------- */
/*  Dúvidas e rodapé                                                          */
/* -------------------------------------------------------------------------- */

export function Faq() {
  return (
    <section
      id="duvidas"
      aria-labelledby="faq-title"
      className="border-t border-border py-16 sm:py-24"
    >
      <div className="mx-auto grid max-w-6xl gap-10 px-5 sm:px-8 lg:grid-cols-[minmax(0,4fr)_minmax(0,8fr)] lg:gap-16">
        <div data-reveal className="text-center lg:sticky lg:top-28 lg:self-start lg:text-left">
          <Target
            className="mx-auto size-12 text-primary-ink lg:mx-0"
            strokeWidth={1.5}
            aria-hidden
          />
          <Eyebrow className="mt-5">Tire suas dúvidas</Eyebrow>
          <SectionTitle id="faq-title" className="mt-4 text-[clamp(2.5rem,6vw,4.5rem)]">
            FAQ
          </SectionTitle>
          <div className="mt-8 hidden lg:block">
            <SalesButton className="w-full" />
          </div>
        </div>

        <div>
          <Accordion type="single" collapsible defaultValue="faq-0" className="space-y-3">
            {faq.map((item, index) => (
              <AccordionItem
                key={item.question}
                value={`faq-${index}`}
                className="border border-foreground/15 bg-card transition-[border-color,box-shadow] duration-200 data-[state=open]:border-foreground data-[state=open]:shadow-[6px_6px_0_var(--color-primary)]"
              >
                <AccordionPrimitive.Header className="flex">
                  <AccordionPrimitive.Trigger className="group flex min-h-16 w-full cursor-pointer items-center justify-between gap-4 px-5 py-4 text-left text-base font-semibold sm:text-lg">
                    {item.question}
                    <span
                      aria-hidden
                      className="grid size-8 shrink-0 place-items-center border border-foreground/30 transition-colors group-data-[state=open]:border-foreground group-data-[state=open]:bg-foreground group-data-[state=open]:text-background"
                    >
                      <Plus className="size-4 group-data-[state=open]:hidden" />
                      <Minus className="hidden size-4 group-data-[state=open]:block" />
                    </span>
                  </AccordionPrimitive.Trigger>
                </AccordionPrimitive.Header>
                <AccordionContent className="px-5 pb-5 text-base leading-relaxed text-ink-soft">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-10 text-center lg:hidden">
            <SalesButton className="w-full sm:w-auto" />
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="on-dark bg-secondary px-5 pb-32 pt-10 text-secondary-foreground md:pb-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-5 text-center sm:flex-row sm:justify-between sm:text-left">
        <span className="display-type grid size-10 place-items-center bg-primary text-[0.95rem] text-primary-foreground">
          HPC
        </span>
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary-foreground/70">
          High Performance Creator • The Creators Club
        </p>
      </div>
    </footer>
  );
}
