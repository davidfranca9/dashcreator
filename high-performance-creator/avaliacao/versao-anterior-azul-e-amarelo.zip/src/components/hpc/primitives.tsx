import type { ComponentProps, ReactNode } from "react";
import { ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { CTA_LABEL } from "@/lib/landing";
import { cn } from "@/lib/utils";

export function Eyebrow({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <p
      className={cn(
        "eyebrow",
        tone === "light" ? "text-primary-ink" : "text-primary-foreground",
        className,
      )}
    >
      {children}
    </p>
  );
}

export function SectionTitle({
  id,
  children,
  className,
}: {
  id?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <h2
      id={id}
      className={cn(
        "display-type text-balance text-[clamp(1.75rem,4.4vw,3rem)] leading-[1.1]",
        className,
      )}
    >
      {children}
    </h2>
  );
}

type SalesButtonProps = Omit<ComponentProps<"a">, "children"> & {
  size?: "sales" | "header" | "bar";
  children?: ReactNode;
};

export function SalesButton({
  href = "#inscricao",
  size = "sales",
  className,
  children = CTA_LABEL,
  ...props
}: SalesButtonProps) {
  return (
    <Button asChild variant="sales" size={size} className={className}>
      <a href={href} {...props}>
        {children}
        <ArrowRight
          aria-hidden
          className="transition-transform duration-150 group-hover:translate-x-1"
        />
      </a>
    </Button>
  );
}
